import time

print("Example task 1 ranned!")
time.sleep(10)
print("Прошло 10 секунд!")
